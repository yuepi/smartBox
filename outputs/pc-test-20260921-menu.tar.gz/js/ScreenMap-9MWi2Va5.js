import{a as e,r as t}from"./chunk-B3GIXBrH.js";import{An as n,Fn as r,Nn as i,Qn as a,cn as o,ir as s,jr as c,sn as l,ti as u,tr as d,vr as f,zn as p}from"../jse/index-index-D1g8iM2Y.js";import{t as m}from"./_plugin-vue_export-helper-BkqkSK9U.js";import{t as h}from"./dist-DBpaUw9k.js";o();var g=e(h(),1),_={class:`screen-map-wrapper`},v=p({__name:`index`,props:{center:{},height:{},points:{},zoom:{}},setup(e,{expose:t}){let o=e,p=c(),m=c(!1),h=null,v=null,y=null,b=o.center||{lng:116.397428,lat:39.90923},x=o.zoom||11,S={online:`#00f2ff`,full:`#ffb700`,offline:`#8c9ba5`},C=()=>{if(p.value)if(document.fullscreenElement){var e,t;(e=(t=document).exitFullscreen)==null||e.call(t)}else{var n,r;(n=(r=p.value).requestFullscreen)==null||n.call(r)}},w=()=>{m.value=!!document.fullscreenElement,setTimeout(()=>{v&&(v.resize(),v.setFitView())},200)},T=()=>new Promise((e,t)=>{if(!navigator.geolocation){t(Error(`浏览器不支持定位`));return}navigator.geolocation.getCurrentPosition(t=>{e({lng:t.coords.longitude,lat:t.coords.latitude})},e=>t(e),{enableHighAccuracy:!0,timeout:5e3,maximumAge:6e4})}),E=function(){var e=l(function*(){try{var e;h=yield g.default.load({key:`a2f1a77c9013204bd92f42e88da34657`,version:`2.0`,plugins:[`AMap.MarkerCluster`]});let t=b;try{t=yield T()}catch(e){console.warn(`⚠️ 获取位置失败，使用默认中心:`,b)}v=new h.Map(p.value,{zoom:x,center:[t.lng,t.lat],viewMode:`2D`,mapStyle:`amap://styles/darkblue`,showIndoorMap:!1,features:[`bg`,`road`,`building`,`point`]}),D((e=o.points)!=null&&e.length?o.points:O(500))}catch(e){console.error(`地图加载失败：`,e)}});return function(){return e.apply(this,arguments)}}(),D=e=>{if(!v||!h)return;y&&(y.setMap(null),y=null);let t=e.map(e=>({lnglat:[e.lng,e.lat],name:e.name,value:e.value,status:e.status||`online`}));y=new h.MarkerCluster(v,t,{gridSize:80,maxZoom:15,renderMarker:e=>{let t=e.data[0],n=`
        <div class="tech-map-dot" style="--dot-color: ${S[t.status]||`#00f2ff`};">
          <div class="dot-pulse"></div>
          <div class="dot-core"></div>
        </div>
      `;e.marker.setContent(n),e.marker.setOffset(new h.Pixel(-18,-18)),e.marker.on(`click`,()=>{let e=t.status===`online`?`在线`:t.status===`full`?`满箱`:`离线`,n=`
          <div class="tech-info-window">
            <div class="info-title">${t.name||`设备`}</div>
            <div class="info-body">
              <div class="info-item">
                <span class="label">投递量:</span>
                <span class="val">${t.value||0} 次</span>
              </div>
              <div class="info-item">
                <span class="label">设备状态:</span>
                <span class="val status-${t.status}">${e}</span>
              </div>
            </div>
          </div>
        `;new h.InfoWindow({content:n,offset:new h.Pixel(0,-15),isCustom:!0}).open(v,t.lnglat)})},renderClusterMarker:e=>{let t=e.count,n=Math.min(t/100,1),r=Math.floor(40+n*20),i=`
        <div class="custom-cluster-node" style="width: ${r}px; height: ${r}px; line-height: ${r}px;">
          <span class="cluster-count">${t}</span>
        </div>
      `;e.marker.setContent(i),e.marker.setOffset(new h.Pixel(-r/2,-r/2))}}),y.on(`click`,e=>{if(e.clusterData&&e.clusterData.length>0){let t=v.getZoom();v.setZoomAndCenter(t+2,e.lnglat)}}),e.length>0&&v.setFitView(null,!1,[60,60,60,60])},O=(e=500)=>{let t=[],n=[`online`,`offline`,`full`];for(let r=0;r<e;r++){let e=116.397428+(Math.random()-.5)*.4,i=39.90923+(Math.random()-.5)*.4,a=n[Math.floor(Math.random()*n.length)];t.push({lng:e,lat:i,name:`设备 #${r+1}`,value:Math.floor(Math.random()*200),status:a})}return t};return f(()=>o.points,e=>{v&&e!=null&&e.length&&D(e)},{deep:!0}),d(()=>{E(),document.addEventListener(`fullscreenchange`,w)}),a(()=>{y&&y.setMap(null),v&&(v.destroy(),v=null),document.removeEventListener(`fullscreenchange`,w)}),t({renderCluster:D,toggleFullscreen:C}),(t,a)=>(s(),i(`div`,_,[n(`div`,{ref_key:`mapContainer`,ref:p,class:`map-container`,style:u({height:e.height||`100%`})},[...a[0]||(a[0]=[r(`<div class="map-legend" data-v-b2b46c55><span class="legend-item" data-v-b2b46c55><span class="dot online" data-v-b2b46c55></span>在线</span><span class="legend-item" data-v-b2b46c55><span class="dot full" data-v-b2b46c55></span>满箱</span><span class="legend-item" data-v-b2b46c55><span class="dot offline" data-v-b2b46c55></span>离线</span></div>`,1)])],4)]))}}),y=t({default:()=>b}),b=m(v,[[`__scopeId`,`data-v-b2b46c55`]]);export{y as n,b as t};