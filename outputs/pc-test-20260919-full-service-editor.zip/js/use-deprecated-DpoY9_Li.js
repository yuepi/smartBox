import{Br as e,vr as t}from"../jse/index-index-Bt_5IW-A.js";import{t as n}from"./error-CwmBiaLF.js";var r=({from:r,replacement:i,scope:a,version:o,ref:s,type:c=`API`},l)=>{t(()=>e(l),e=>{e&&n(a,`[${c}] ${r} is about to be deprecated in version ${o}, please use ${i} instead.
For more detail, please visit: ${s}
`)},{immediate:!0})};export{r as t};