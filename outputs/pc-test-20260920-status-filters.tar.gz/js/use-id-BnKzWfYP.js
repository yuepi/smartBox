import{Bn as e,Br as t,G as n,Wn as r,Y as i}from"../jse/index-index-7GYwd6c9.js";import{o as a}from"./install-BHj7z1BF.js";import{t as o}from"./error-CdPzFCRm.js";var s={prefix:Math.floor(Math.random()*1e4),current:0},c=Symbol(`elIdInjection`),l=()=>e()?r(c,s):s,u=e=>{let r=l();!i&&r===s&&o(`IdInjection`,`Looks like you are using server rendering, you must provide a id provider to ensure the hydration process to be succeed
usage: app.provide(ID_INJECTION_KEY, {
  prefix: number,
  current: number,
})`);let c=a();return n(()=>t(e)||`${c.value}-id-${r.prefix}-${r.current++}`)};export{l as n,u as t};